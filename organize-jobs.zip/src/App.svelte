<script lang="ts">
  import Router from "svelte-spa-router";
  // @ts-ignore
  import routes from "virtual:generated-pages-svelte";
  import "./tailwind.css";
</script>

<Router {routes} />

<style>
  :global(*) {
    word-wrap: break-word;
  }
  /* chrome extension */
  :global(body) {
    width: 350px;
    height: 500px;
    font-size: 16px;
  }
</style>
